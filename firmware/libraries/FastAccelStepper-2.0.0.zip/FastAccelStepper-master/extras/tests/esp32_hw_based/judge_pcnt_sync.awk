BEGIN {
	pass = 1
}

/ @0 acceleration/ {
  # ignore lines, if pulse counter not set
  next
}

# This is for running motor
/^M[17]:/ {
	api = substr($2,2)
	pcnt = substr($3,2,length($3)-2)
	if (pcnt < 0) {
		if (api > 0) {
			while (pcnt < 0) {
				pcnt += 32767
			}
		}
	}
	api = api % 32767
	delta = pcnt - api
	if (api > pcnt) {
		delta = api - pcnt
	}
	# 128: IDF5/6 can commit 64 channel symbols + one 32-symbol chunk
	# before the pin catches up. Stopped ">> M" lines stay exact.
	if ((delta > 128) && (delta < 32767-128)) {
	    print
		print api, pcnt
		pass = 0
		print "FAIL HERE ^^^"
	}
}
# This is for selected motor
/^>> M[17]:/ {
	print
	api = substr($3,2)
	api = api % 32767
	pcnt = substr($4,2,length($4)-2)
	if (pcnt < 0) {
	    pcnt += 32767
	}
	if (api != pcnt) {
		print api, pcnt
		pass = 0
		print "FAIL HERE ^^^"
	}
}

END {
	if (pass) {
		print "PASS"
	}
	else {
		print "FAIL"
	}
}
