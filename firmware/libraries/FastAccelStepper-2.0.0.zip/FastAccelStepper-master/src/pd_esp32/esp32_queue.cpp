#include "fas_queue/stepper_queue.h"

#if defined(SUPPORT_ESP32_I2S)
#include "pd_esp32/i2s_manager.h"
#endif

#if defined(SUPPORT_ESP32)

#include <esp_task_wdt.h>

#if defined(SUPPORT_DYNAMIC_ALLOCATION)
#if defined(SUPPORT_SELECT_DRIVER_TYPE)
uint8_t StepperQueue::queues_allocated = 0;
#if defined(SUPPORT_ESP32_I2S)
bool StepperQueue::_i2s_mux_initialized = false;
uint32_t StepperQueue::_i2s_mux_allocated_bitmask = 0;
I2sManager* StepperQueue::_i2s_mux_manager = nullptr;
#endif
#ifdef SUPPORT_ESP32_MCPWM_PCNT
uint8_t StepperQueue::_mcpwm_pcnt_allocated = 0;
#endif
#if (defined(SUPPORT_ESP32_RMT_V1) || defined(SUPPORT_ESP32_RMT_V2))
uint8_t StepperQueue::_rmt_allocated = 0;
#endif
#else
uint8_t StepperQueue::queues_allocated = 0;
#endif  // SUPPORT_SELECT_DRIVER_TYPE
#endif

void StepperQueue::init(uint8_t queue_num, uint8_t step_pin) {
  (void)queue_num;
  (void)step_pin;
}

void StepperQueue::connect() {
#if defined(SUPPORT_SELECT_DRIVER_TYPE) && defined(SUPPORT_ESP32_I2S)
  if (_driver_type == FasDriver::I2S_DIRECT ||
      _driver_type == FasDriver::I2S_MUX) {
    return;
  }
#endif
#if (defined(SUPPORT_ESP32_RMT_V1) || defined(SUPPORT_ESP32_RMT_V2))
#if defined(SUPPORT_SELECT_DRIVER_TYPE)
  if (_driver_type == FasDriver::RMT) {
    connect_rmt();
    return;
  }
#elif !defined(SUPPORT_ESP32_MCPWM_PCNT)
  connect_rmt();
  return;
#endif
#endif
#ifdef SUPPORT_ESP32_MCPWM_PCNT
  connect_mcpwm_pcnt();
#endif
}

void StepperQueue::disconnect() {
#if defined(SUPPORT_SELECT_DRIVER_TYPE) && defined(SUPPORT_ESP32_I2S)
  if (_driver_type == FasDriver::I2S_DIRECT ||
      _driver_type == FasDriver::I2S_MUX) {
    return;
  }
#endif
#if (defined(SUPPORT_ESP32_RMT_V1) || defined(SUPPORT_ESP32_RMT_V2))
#if defined(SUPPORT_SELECT_DRIVER_TYPE)
  if (_driver_type == FasDriver::RMT) {
    disconnect_rmt();
    return;
  }
#elif !defined(SUPPORT_ESP32_MCPWM_PCNT)
  disconnect_rmt();
  return;
#endif
#endif
#ifdef SUPPORT_ESP32_MCPWM_PCNT
  disconnect_mcpwm_pcnt();
#endif
}

bool StepperQueue::isReadyForCommands() const {
#if defined(SUPPORT_ESP32_I2S)
#if defined(SUPPORT_SELECT_DRIVER_TYPE)
  if (_driver_type == FasDriver::I2S_DIRECT ||
      _driver_type == FasDriver::I2S_MUX)
#endif
  {
    return isReadyForCommands_i2s();
  }
#endif
#if (defined(SUPPORT_ESP32_RMT_V1) || defined(SUPPORT_ESP32_RMT_V2)) && defined(SUPPORT_ESP32_MCPWM_PCNT)
#if defined(SUPPORT_SELECT_DRIVER_TYPE)
  if (_driver_type == FasDriver::RMT) {
    return isReadyForCommands_rmt();
  }
  return isReadyForCommands_mcpwm_pcnt();
#else
#error "RMT + MCPWM_PCNT requires SUPPORT_SELECT_DRIVER_TYPE"
#endif
#elif defined(SUPPORT_ESP32_MCPWM_PCNT)
  return isReadyForCommands_mcpwm_pcnt();
#elif (defined(SUPPORT_ESP32_RMT_V1) || defined(SUPPORT_ESP32_RMT_V2))
  return isReadyForCommands_rmt();
#else
#error "Nothing defined here"
#endif
}

void StepperQueue::startQueue() {
#if defined(SUPPORT_SELECT_DRIVER_TYPE) && defined(SUPPORT_ESP32_I2S)
  if (_driver_type == FasDriver::I2S_DIRECT ||
      _driver_type == FasDriver::I2S_MUX) {
    startQueue_i2s();
    return;
  }
#endif
#if (defined(SUPPORT_ESP32_RMT_V1) || defined(SUPPORT_ESP32_RMT_V2))
#if defined(SUPPORT_SELECT_DRIVER_TYPE)
  if (_driver_type == FasDriver::RMT)
#endif
  {
    startQueue_rmt();
    return;
  }
#endif
#ifdef SUPPORT_ESP32_MCPWM_PCNT
  startQueue_mcpwm_pcnt();
#endif
}

void StepperQueue::forceStop() {
#if defined(SUPPORT_PAUSE_CMD_COUNTING)
  // every branch below leaves the queue empty with the driver's pipeline
  // dropped (rmt_disable / i2s channel disabled / timer off), so the next
  // direction change needs no drain
  markPipelineDrained();
#endif
#if defined(SUPPORT_SELECT_DRIVER_TYPE) && defined(SUPPORT_ESP32_I2S)
  if (_driver_type == FasDriver::I2S_DIRECT ||
      _driver_type == FasDriver::I2S_MUX) {
    forceStop_i2s();
    return;
  }
#endif
#if (defined(SUPPORT_ESP32_RMT_V1) || defined(SUPPORT_ESP32_RMT_V2))
#if defined(SUPPORT_SELECT_DRIVER_TYPE)
  if (_driver_type == FasDriver::RMT)
#endif
  {
    forceStop_rmt();
    return;
  }
#endif
#ifdef SUPPORT_ESP32_MCPWM_PCNT
  forceStop_mcpwm_pcnt();
#endif
}

uint16_t StepperQueue::_getPerformedPulses() const {
#if defined(SUPPORT_ESP32_I2S)
#if defined(SUPPORT_SELECT_DRIVER_TYPE)
  if (_driver_type == FasDriver::I2S_DIRECT ||
      _driver_type == FasDriver::I2S_MUX)
#endif
  {
    return _getPerformedPulses_i2s();
  }
#endif
#if (defined(SUPPORT_ESP32_RMT_V1) || defined(SUPPORT_ESP32_RMT_V2))
#if defined(SUPPORT_SELECT_DRIVER_TYPE)
  if (_driver_type == FasDriver::RMT)
#endif
  {
    return _getPerformedPulses_rmt();
  }
#endif
#ifdef SUPPORT_ESP32_MCPWM_PCNT
  return _getPerformedPulses_mcpwm_pcnt();
#endif
  return 0;
}

bool StepperQueue::isValidStepPin(uint8_t step_pin) {
  gpio_drive_cap_t strength;
  esp_err_t res = gpio_get_drive_capability((gpio_num_t)step_pin, &strength);
  return res == ESP_OK;
}

#if defined(SUPPORT_SELECT_DRIVER_TYPE) && defined(SUPPORT_DYNAMIC_ALLOCATION)
// dynamic allocation for espidf >=5.3 with support for mcpwm/pcnt, rmt, and i2s
StepperQueue* StepperQueue::tryAllocateQueue(FastAccelStepperEngine* engine,
                                             FasDriver driver,
                                             uint8_t step_pin) {
  (void)engine;
  if (StepperQueue::queues_allocated >= MAX_STEPPER) {
    return nullptr;
  }

  if (step_pin & PIN_EXTERNAL_FLAG) {
    return nullptr;
  }
  if (step_pin & PIN_I2S_FLAG) {
#if !defined(SUPPORT_ESP32_I2S)
    return nullptr;
#endif
    if (!StepperQueue::_i2s_mux_initialized) {
      return nullptr;
    }
    uint8_t slot = step_pin & 0x1F;
    if (slot >= 32) {
      return nullptr;
    }
    uint32_t bit = 1UL << slot;
    if (StepperQueue::_i2s_mux_allocated_bitmask & bit) {
      return nullptr;
    }
    StepperQueue::_i2s_mux_allocated_bitmask |= bit;
    StepperQueue* q = new StepperQueue();
    q->_initVars();
    q->_driver_type = FasDriver::I2S_MUX;
    q->i2s_mgr = StepperQueue::_i2s_mux_manager;
    q->_i2s_mux_step_byte_offset = i2s_mux_byte_offset(slot);
    q->_i2s_mux_step_bit_mask = i2s_mux_bit_mask(slot);
    q->init_i2s(step_pin);
    return q;
  }

  if (!StepperQueue::isValidStepPin(step_pin)) {
    return nullptr;
  }

#if defined(SUPPORT_ESP32_MCPWM_PCNT)
  if (driver == FasDriver::MCPWM_PCNT) {
    if (StepperQueue::_mcpwm_pcnt_allocated >= QUEUES_MCPWM_PCNT) {
      return nullptr;
    }
    StepperQueue* q = new StepperQueue();
    q->_initVars();
    q->_driver_type = FasDriver::MCPWM_PCNT;
    q->init_mcpwm_pcnt(StepperQueue::_mcpwm_pcnt_allocated, step_pin);
    StepperQueue::_mcpwm_pcnt_allocated++;
    return q;
  }
#endif

#if (defined(SUPPORT_ESP32_RMT_V1) || defined(SUPPORT_ESP32_RMT_V2))
  if (driver == DRIVER_RMT) {
    if (StepperQueue::_rmt_allocated >= QUEUES_RMT) {
      return nullptr;
    }
    StepperQueue* q = new StepperQueue();
    q->_initVars();
    q->_driver_type = FasDriver::RMT;
    StepperQueue::_rmt_allocated++;
    q->init_rmt(0, step_pin);
    return q;
  }
#endif
#if defined(SUPPORT_ESP32_I2S)
  if (driver == DRIVER_I2S_DIRECT) {
    I2sManager* mgr = I2sManager::create((gpio_num_t)step_pin, I2S_GPIO_UNUSED,
                                         I2S_GPIO_UNUSED);
    if (mgr != nullptr) {
      StepperQueue* q = new StepperQueue();
      q->_initVars();
      q->_driver_type = FasDriver::I2S_DIRECT;
      q->i2s_mgr = mgr;
      q->init_i2s(step_pin);
      return q;
    }
  }
#endif

  if (driver != DRIVER_DONT_CARE) {
    return nullptr;
  }
  StepperQueue* q = tryAllocateQueue(engine, DRIVER_RMT, step_pin);
  if (q == nullptr) {
    q = tryAllocateQueue(engine, DRIVER_I2S_DIRECT, step_pin);
  }
#if defined(SUPPORT_ESP32_MCPWM_PCNT)
  if (q == nullptr) {
    q = tryAllocateQueue(engine, FasDriver::MCPWM_PCNT, step_pin);
  }
#endif
  return q;
}
#endif  // SUPPORT_SELECT_DRIVER_TYPE && SUPPORT_DYNAMIC_ALLOCATION

#if !defined(SUPPORT_SELECT_DRIVER_TYPE) && defined(SUPPORT_DYNAMIC_ALLOCATION)
StepperQueue* StepperQueue::tryAllocateQueue(FastAccelStepperEngine* engine,
                                             uint8_t step_pin) {
  (void)engine;
  if (StepperQueue::queues_allocated >= MAX_STEPPER) {
    return nullptr;
  }

  if (step_pin & PIN_EXTERNAL_FLAG) {
    return nullptr;
  }

  if (!StepperQueue::isValidStepPin(step_pin)) {
    return nullptr;
  }

  StepperQueue* q = new StepperQueue();
  q->_initVars();
#if (defined(SUPPORT_ESP32_RMT_V1) || defined(SUPPORT_ESP32_RMT_V2))
  q->init_rmt(0, step_pin);
#endif
  StepperQueue::queues_allocated++;
  return q;
}
#endif  // !SUPPORT_SELECT_DRIVER_TYPE && SUPPORT_DYNAMIC_ALLOCATION

#if !defined(SUPPORT_SELECT_DRIVER_TYPE) && !defined(SUPPORT_DYNAMIC_ALLOCATION)
StepperQueue* StepperQueue::tryAllocateQueue(FastAccelStepperEngine* engine,
                                             uint8_t step_pin) {
  (void)engine;
  if (step_pin & PIN_EXTERNAL_FLAG) {
    return nullptr;
  }

  if (!StepperQueue::isValidStepPin(step_pin)) {
    return nullptr;
  }

  for (uint8_t i = 0; i < NUM_QUEUES; i++) {
    if (fas_queue[i]._step_pin == step_pin) {
      return nullptr;
    }
  }

  for (uint8_t i = 0; i < NUM_QUEUES; i++) {
    if (fas_queue[i]._step_pin == PIN_UNDEFINED) {
      StepperQueue* q = &fas_queue[i];
      q->_initVars();
#ifdef SUPPORT_ESP32_MCPWM_PCNT
      if (i < QUEUES_MCPWM_PCNT) {
        q->init_mcpwm_pcnt(i, step_pin);
      } else
#endif
      {
        q->init_rmt(
#ifdef SUPPORT_ESP32_MCPWM_PCNT
            i - QUEUES_MCPWM_PCNT,
#else
            i,
#endif
            step_pin);
      }
      return q;
    }
  }
  return nullptr;
}
#endif  // !SUPPORT_SELECT_DRIVER_TYPE && !SUPPORT_DYNAMIC_ALLOCATION

#if defined(SUPPORT_SELECT_DRIVER_TYPE) && !defined(SUPPORT_DYNAMIC_ALLOCATION)
// Static allocation with driver selection (ESP-IDF 4.x)
// Queue ranges: [0..QUEUES_MCPWM_PCNT-1] = MCPWM/PCNT
//               [QUEUES_MCPWM_PCNT..QUEUES_MCPWM_PCNT+QUEUES_RMT-1] = RMT
//               [QUEUES_MCPWM_PCNT+QUEUES_RMT..] = I2S
#if defined(SUPPORT_ESP32_MCPWM_PCNT) && (QUEUES_MCPWM_PCNT > 0)
static uint8_t mcpwm_pcnt_allocated = 0;
#endif
#if (defined(SUPPORT_ESP32_RMT_V1) || defined(SUPPORT_ESP32_RMT_V2)) && (QUEUES_RMT > 0)
static uint8_t rmt_allocated = 0;
#endif
#if defined(SUPPORT_ESP32_I2S) && (QUEUES_I2S > 0)
static uint8_t i2s_allocated = 0;
#endif

StepperQueue* StepperQueue::tryAllocateQueue(FastAccelStepperEngine* engine,
                                             FasDriver driver,
                                             uint8_t step_pin) {
  (void)engine;
  if (step_pin & PIN_EXTERNAL_FLAG) {
    return nullptr;
  }

  if (!StepperQueue::isValidStepPin(step_pin)) {
    return nullptr;
  }

  for (uint8_t i = 0; i < NUM_QUEUES; i++) {
    if (fas_queue[i]._step_pin == step_pin) {
      return nullptr;
    }
  }

#if defined(SUPPORT_ESP32_MCPWM_PCNT) && (QUEUES_MCPWM_PCNT > 0)
  if (driver == FasDriver::MCPWM_PCNT) {
    if (mcpwm_pcnt_allocated >= QUEUES_MCPWM_PCNT) {
      return nullptr;
    }
    StepperQueue* q = &fas_queue[mcpwm_pcnt_allocated];
    q->_initVars();
    q->_driver_type = FasDriver::MCPWM_PCNT;
    q->init_mcpwm_pcnt(mcpwm_pcnt_allocated, step_pin);
    mcpwm_pcnt_allocated++;
    return q;
  }
#endif

#if (defined(SUPPORT_ESP32_RMT_V1) || defined(SUPPORT_ESP32_RMT_V2)) && (QUEUES_RMT > 0)
  if (driver == FasDriver::RMT) {
    if (rmt_allocated >= QUEUES_RMT) {
      return nullptr;
    }
    uint8_t idx = QUEUES_MCPWM_PCNT + rmt_allocated;
    StepperQueue* q = &fas_queue[idx];
    q->_initVars();
    q->_driver_type = FasDriver::RMT;
    q->init_rmt(rmt_allocated, step_pin);
    rmt_allocated++;
    return q;
  }
#endif

#if defined(SUPPORT_ESP32_I2S) && (QUEUES_I2S > 0)
  if (driver == FasDriver::I2S_DIRECT) {
    uint8_t i2s_start = QUEUES_MCPWM_PCNT + QUEUES_RMT;
    if (i2s_allocated >= QUEUES_I2S) {
      return nullptr;
    }
    uint8_t idx = i2s_start + i2s_allocated;
    StepperQueue* q = &fas_queue[idx];
    q->_initVars();
    q->_driver_type = FasDriver::I2S_DIRECT;
    q->init_i2s(step_pin);
    i2s_allocated++;
    return q;
  }
#endif

  if (driver == FasDriver::DONT_CARE) {
    StepperQueue* q = nullptr;
#if defined(SUPPORT_ESP32_MCPWM_PCNT) && (QUEUES_MCPWM_PCNT > 0)
    q = tryAllocateQueue(engine, FasDriver::MCPWM_PCNT, step_pin);
    if (q != nullptr) return q;
#endif
#if (defined(SUPPORT_ESP32_RMT_V1) || defined(SUPPORT_ESP32_RMT_V2)) && (QUEUES_RMT > 0)
    q = tryAllocateQueue(engine, FasDriver::RMT, step_pin);
    if (q != nullptr) return q;
#endif
#if defined(SUPPORT_ESP32_I2S) && (QUEUES_I2S > 0)
    q = tryAllocateQueue(engine, FasDriver::I2S_DIRECT, step_pin);
    if (q != nullptr) return q;
#endif
  }

  return nullptr;
}
#endif  // SUPPORT_SELECT_DRIVER_TYPE && !SUPPORT_DYNAMIC_ALLOCATION

void StepperTask(void* parameter) {
  FastAccelStepperEngine* engine =
      static_cast<FastAccelStepperEngine*>(parameter);
  while (true) {
    engine->manageSteppers();
#if ESP_IDF_VERSION_MAJOR == 4
    esp_task_wdt_reset();
#endif
    const TickType_t delay_time =
        (engine->_task_rate() + portTICK_PERIOD_MS - 1) / portTICK_PERIOD_MS;
    vTaskDelay(delay_time);
  }
}

int32_t StepperQueue::getCurrentPosition() const {
  fasDisableInterrupts();
  uint32_t pos = (uint32_t)queue_end.pos;
  uint8_t rp = read_idx;
  bool is_empty = (rp == next_write_idx);
  const struct queue_entry* e = &entry[rp & QUEUE_LEN_MASK];
  uint16_t pos_last16 = e->start_pos_last16;
  uint8_t steps = e->steps;
  int16_t done_p = (int16_t)_getPerformedPulses();
  fasEnableInterrupts();
  if (done_p == 0) {
    fasDisableInterrupts();
    rp = read_idx;
    is_empty = (rp == next_write_idx);
    e = &entry[rp & QUEUE_LEN_MASK];
    pos_last16 = e->start_pos_last16;
    steps = e->steps;
    done_p = (int16_t)_getPerformedPulses();
    fasEnableInterrupts();
  }
  if (!is_empty) {
    uint16_t pos16 = pos & 0xffff;
    uint8_t transition = ((pos16 >> 12) & 0x0c) | (pos_last16 >> 14);
    switch (transition) {
      case 0:   // 00 00
      case 5:   // 01 01
      case 10:  // 10 10
      case 15:  // 11 11
        break;
      case 1:   // 00 01
      case 6:   // 01 10
      case 11:  // 10 11
      case 12:  // 11 00
        pos += 0x4000;
        break;
      case 4:   // 01 00
      case 9:   // 10 01
      case 14:  // 11 10
      case 3:   // 00 11
        pos -= 0x4000;
        break;
      case 2:   // 00 10
      case 7:   // 01 11
      case 8:   // 10 00
      case 13:  // 11 01
        break;  // TODO: ERROR
    }
    pos = (int32_t)((pos & 0xffff0000) | pos_last16);

    if (steps != 0) {
      int16_t adjust = e->countUp ? done_p : -done_p;
      pos += adjust;
    }
  }
  return pos;
}

void fas_init_engine(FastAccelStepperEngine* engine, uint8_t cpu_core) {
#if ESP_IDF_VERSION_MAJOR == 4
#define STACK_SIZE 2000
#define PRIORITY configMAX_PRIORITIES
#else
// I2S adds i2s_channel_write() to StepperTask; that IDF blocking call
// consumes ~3 KB of stack by itself.  Use 6 KB to be safe.
#define STACK_SIZE 6000
#define PRIORITY (configMAX_PRIORITIES - 1)
#endif
  engine->task_rate(DELAY_MS_BASE);
  if (cpu_core > 1) {
    xTaskCreate(StepperTask, "StepperTask", STACK_SIZE, engine, PRIORITY, NULL);
  } else {
    xTaskCreatePinnedToCore(StepperTask, "StepperTask", STACK_SIZE, engine,
                            PRIORITY, NULL, cpu_core);
  }
}

AqeResultCode FastAccelStepperEngine::synchronizedStart(
    FastAccelStepper** const steppers, uint8_t cnt) {
  AqeResultCode rc = AqeResultCode::OK;
  fasDisableInterrupts();

  // Phase 1: arm every not-yet-running stepper (no hardware trigger).
  // Skip running queues; an empty queue must not abort the others.
  for (uint8_t i = 0; i < cnt; i++) {
    StepperQueue* q = steppers[i]->_queue();
    if (q == nullptr || q->isRunning()) {
      continue;
    }
    if (q->isQueueEmpty()) {
      continue;  // matches generic contract: empty does not stop the others
    }
    esp32_syncStart_arm(q);
  }

  // Phase 2: one native trigger per group; groups without a native
  // trigger (I2S direct, MCPWM, RMT IDF4) did their trigger in arm().
  esp32_sync_trigger_rmt();  // rmt_sync_reset() on the shared manager

  fasEnableInterrupts();
  return rc;
}

#ifdef SUPPORT_ESP32_I2S
void StepperQueue::syncStart_arm_i2s() {
  // I2S mux/direct: set _isRunning = true; first steps appear in the next DMA
  // callback. The trigger is effectively the DMA done callback, which already
  // groups all mux steppers on one shared manager. No separate trigger needed.
  _isRunning = true;
}
#endif

#ifdef SUPPORT_ESP32_MCPWM_PCNT
void StepperQueue::syncStart_arm_mcpwm_pcnt() {
  // MCPWM/PCNT: trigger = arm (startQueue performs the actual start).
  // The synchronizedStart arm phase just calls startQueue directly.
  startQueue_mcpwm_pcnt();
}
#endif

#if (defined(SUPPORT_ESP32_RMT_V1) || defined(SUPPORT_ESP32_RMT_V2))
#if defined(SUPPORT_ESP32_RMT_V1)
// IDF4 RMT: trigger = arm (startQueue starts the hardware directly).
// The syncStart_arm just calls the existing startQueue.
// esp32_sync_trigger_rmt is a no-op (declared in header).
void StepperQueue::syncStart_arm_rmt() { startQueue_rmt(); }
#endif
#endif

#if defined(SUPPORT_ESP32_RMT_SYNC)
// Per-stepper prepare for RMT on IDF5/6 with hardware sync support: do
// everything except starting the transmission. The channels are collected
// and started together by esp32_sync_trigger_rmt().
//
// IDF's RMT sync manager is created with the complete set of TX channels to
// be managed: every managed channel is put in a waiting state until
// rmt_transmit() has been called on all of them, then they start together.
// There is no add/remove-channel API, so the manager is created on demand
// for exactly the channels armed in this synchronizedStart() call.
static StepperQueue* _sync_rmt_queues[QUEUES_RMT];
static uint8_t _sync_rmt_cnt = 0;

void StepperQueue::syncStart_prepare_rmt() {
  if (channel == nullptr) {
    return;
  }

  // Direction pin toggle (same as startQueue_rmt)
  uint8_t rp = read_idx;
  if (rp == next_write_idx) {
    return;
  }
  if (entry[rp & QUEUE_LEN_MASK].toggle_dir) {
    LL_TOGGLE_PIN(dirPin);
    entry[rp & QUEUE_LEN_MASK].toggle_dir = false;
  }

  _isRunning = true;
  _rmtStopped = false;

  // Reset the encoder (same as startQueue_rmt)
  _tx_encoder->reset(_tx_encoder);

  // Enable channel if not already enabled. The sync manager requires all
  // managed channels to be enabled before rmt_new_sync_manager().
  if (!_channel_enabled) {
    rmt_enable(channel);
    _channel_enabled = true;
  }

  if (_sync_rmt_cnt < QUEUES_RMT) {
    _sync_rmt_queues[_sync_rmt_cnt++] = this;
  }
}

void StepperQueue::syncStart_transmit_rmt() {
  int payload = 0;
  rmt_transmit_config_t tx_config;
  tx_config.loop_count = 0;
  tx_config.flags.eot_level = 0;  // output level at end of transmission
  tx_config.flags.queue_nonblocking = 1;
  esp_err_t rc = rmt_transmit(channel, _tx_encoder, &payload, 1, &tx_config);
  (void)rc;
}

// Group trigger for RMT (IDF5/6): create one sync manager for all armed
// channels, kick off every transmission (held by the manager) and release
// the manager again so the channels continue independently afterwards.
void esp32_sync_trigger_rmt() {
  uint8_t cnt = _sync_rmt_cnt;
  _sync_rmt_cnt = 0;
  if (cnt == 0) {
    return;
  }

  rmt_sync_manager_handle_t sync_mgr = nullptr;
  rmt_channel_handle_t channels[QUEUES_RMT];
  for (uint8_t i = 0; i < cnt; i++) {
    channels[i] = _sync_rmt_queues[i]->channel;
  }

  // A single channel does not need a sync manager. On error (e.g. channels
  // spread over several RMT groups) fall back to unsynchronized starts.
  if (cnt > 1) {
    rmt_sync_manager_config_t sync_config = {.tx_channel_array = channels,
                                             .array_size = cnt};
    if (rmt_new_sync_manager(&sync_config, &sync_mgr) != ESP_OK) {
      sync_mgr = nullptr;
    }
  }

  // The last rmt_transmit() starts all managed channels simultaneously.
  for (uint8_t i = 0; i < cnt; i++) {
    _sync_rmt_queues[i]->syncStart_transmit_rmt();
  }

  if (sync_mgr != nullptr) {
    rmt_del_sync_manager(sync_mgr);
  }
}

#elif defined(SUPPORT_ESP32_RMT_V2)
// IDF5/6 without hardware sync (e.g. ESP32 classic): arm and start directly.
void StepperQueue::syncStart_arm_rmt() {
  if (channel == nullptr) {
    return;
  }

  // Direction pin toggle (same as startQueue_rmt)
  uint8_t rp = read_idx;
  if (rp == next_write_idx) {
    return;
  }
  if (entry[rp & QUEUE_LEN_MASK].toggle_dir) {
    LL_TOGGLE_PIN(dirPin);
    entry[rp & QUEUE_LEN_MASK].toggle_dir = false;
  }

  _isRunning = true;
  _rmtStopped = false;

  // Reset the encoder (same as startQueue_rmt)
  int payload = 0;
  _tx_encoder->reset(_tx_encoder);

  // Enable channel if not already enabled (same as startQueue_rmt)
  if (!_channel_enabled) {
    rmt_enable(channel);
    _channel_enabled = true;
  }

  // config must not be NULL: rmt_transmit() guards all five of
  // {channel, encoder, payload, payload_bytes, config} and returns
  // ESP_ERR_INVALID_ARG for a NULL config, so passing nullptr here made every
  // first synchronizedStart() on ESP32 classic log
  // "rmt: rmt_transmit(530): invalid argument" and start no transmission.
  // Match the values startQueue_rmt() uses. The return value is deliberately
  // ignored here, as it is there: the RMT fill takes over from this point.
  rmt_transmit_config_t tx_config;
  tx_config.loop_count = 0;
  tx_config.flags.eot_level = 0;  // output level at end of transmission
  tx_config.flags.queue_nonblocking = 1;
  rmt_transmit(channel, _tx_encoder, &payload, 1, &tx_config);
}
#endif

#endif
