#ifndef PD_ESP32_I2S_CONSTANTS_H
#define PD_ESP32_I2S_CONSTANTS_H
#if defined(SUPPORT_ESP32_I2S)

#include "fas_ramp/RampCalculator.h"  // US_TO_TICKS

// I2S timing: 16-bit stereo mode
// Sample rate: 250kHz
// Bits per frame: 16-bit L + 16-bit R = 32 bits
// BCLK = 250kHz × 32 bits = 8MHz
// Frame duration = 32 bits / 8MHz = 4µs
// At 16MHz stepper reference: 4µs × 16 = 64 ticks per frame
#define I2S_SAMPLE_RATE_HZ 250000UL
#define I2S_TICKS_PER_FRAME 64
#define I2S_BITS_PER_FRAME 32
#define I2S_BYTES_PER_FRAME 4

// All constants derived from I2S_BLOCK_DURATION_US (per design doc)
#define I2S_BLOCK_DURATION_US 500
#define I2S_BLOCK_COUNT 2
#define I2S_FRAMES_PER_BLOCK \
  (I2S_BLOCK_DURATION_US * I2S_SAMPLE_RATE_HZ / 1000000UL)
#define I2S_BLOCK_TICKS (I2S_FRAMES_PER_BLOCK * I2S_TICKS_PER_FRAME)
#define I2S_BYTES_PER_BLOCK (I2S_FRAMES_PER_BLOCK * I2S_BYTES_PER_FRAME)

// Total buffer (all 2 blocks combined)
#define I2S_TOTAL_FRAMES (I2S_BLOCK_COUNT * I2S_FRAMES_PER_BLOCK)
#define I2S_TOTAL_BYTES (I2S_BLOCK_COUNT * I2S_BYTES_PER_BLOCK)

// Max frequency enforced by addQueueEntry(), not by I2S driver
#define MAX_STEP_FREQ_HZ 200000UL

// Max pulses per block (for tracking array size)
// 500µs × 200kHz = 100, +1 for safety
#define I2S_MAX_PULSES_PER_BLOCK \
  ((I2S_BLOCK_DURATION_US * MAX_STEP_FREQ_HZ / 1000000UL) + 1)

#define I2S_DIRECT_MIN_SPEED_TICKS 80
#define I2S_MUX_MIN_SPEED_TICKS 400

// Drain pause before an I2S_DIRECT direction change. 2 * I2S_BLOCK_TICKS
// (1000 us) assumed the fill lead is two DMA blocks; measured 677..1096 us,
// since the TX FIFO still holds part of a descriptor at DMA EOF. 1200 us
// covers that plus one block of margin.
#define I2S_DIR_DRAIN_US 1200
#define I2S_DIR_DRAIN_TICKS ((uint16_t)US_TO_TICKS(I2S_DIR_DRAIN_US))

// 100kHz step frequency corresponds to 10µs period, so 2µs pulse width is 20%
#define I2S_DEFAULT_PULSE_WIDTH_TICKS 32

// DMA: minimum for continuous streaming (per design doc)
#define I2S_DMA_DESC_NUM 2
#define I2S_DMA_FRAME_NUM I2S_FRAMES_PER_BLOCK

// Convert I2S mux slot (0-31) to 32-bit bit position.
// Direct mapping: slot S → byte S/8, bit S%8
// slot 0 -> bit 0, slot 7 -> bit 7, slot 8 -> bit 8, slot 15 -> bit 15
static inline uint8_t i2s_mux_slot_to_bit_pos(uint8_t slot) { return slot; }

static inline uint8_t i2s_mux_byte_offset(uint8_t slot) {
  return i2s_mux_slot_to_bit_pos(slot) >> 3;
}

static inline uint8_t i2s_mux_bit_mask(uint8_t slot) {
  return 1 << (i2s_mux_slot_to_bit_pos(slot) & 7);
}

static inline uint32_t i2s_mux_bit_mask_u32(uint8_t slot) {
  return 1UL << i2s_mux_slot_to_bit_pos(slot);
}

#endif  // SUPPORT_ESP32_I2S
#endif  // PD_ESP32_I2S_CONSTANTS_H
