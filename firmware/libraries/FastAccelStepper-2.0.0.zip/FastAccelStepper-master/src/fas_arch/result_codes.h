#ifndef FAS_RESULT_CODES_H
#define FAS_RESULT_CODES_H

#include <stdint.h>

#if defined(__AVR__)
#include <avr/pgmspace.h>
#define FAS_PSTR(s) (reinterpret_cast<const char*>(PSTR(s)))
#else
#define FAS_PSTR(s) (s)
#endif

// Cause of a stop, for a planner that co-drives the same queue. Set by
// FastAccelStepper::stopMove()/forceStop()/forceStopAndNewPosition() and
// read-and-cleared via FastAccelStepper::takeStopCause(); see
// extras/doc/engine_sources.md. Shared here so a duck-typed n-axis planner
// and the test SimPort can name the type without including FastAccelStepper.h.
enum class StepperStopCause : uint8_t {
  None = 0,
  StopMove = 1,
  ForceStop = 2,
  ForceStopAndNewPosition = 3,
};

// ### Result codes for addQueueEntry() function of FastAccelStepper
enum class AqeResultCode : int8_t {
  OK = 0,
  QueueFull = 1,
  DirPinIsBusy = 2,
  WaitForEnablePinActive = 3,
  DeviceNotReady = 4,
  DirPin2msPauseAdded = 5,
  DirChangePauseInjected = 6,
  ErrorTicksTooLow = -1,
  ErrorEmptyQueueToStart = -2,
  ErrorNoDirPinToToggle = -3,
  // The command-admission latch is set (queue_add_entry.cpp, ignore_commands).
  // A forceStop() / forceStopAndNewPosition() sets it; only resumeCommands()
  // clears it. MUST stay -5: MoveTimedResultCode::ErrorMoveTooLarge occupies
  // -4 and tmrFrom() is a value-preserving cast, so -4 here would report a
  // suspended queue as MOVE_TIMED_TOO_LARGE_ERROR.
  ErrorCommandsSuspended = -5
};

static inline bool aqeRetry(AqeResultCode code) {
  return (static_cast<int8_t>(code)) > 0;
}
static inline bool aqeRetryImmediately(AqeResultCode code) {
  return code == AqeResultCode::DirChangePauseInjected;
}
static inline bool aqeIsOk(AqeResultCode status) {
  return status == AqeResultCode::OK;
}
static inline bool aqeIsPauseInjected(AqeResultCode code) {
  return (code == AqeResultCode::DirPin2msPauseAdded) ||
         (code == AqeResultCode::DirChangePauseInjected);
}

static inline const char* toString(AqeResultCode code) {
  switch (code) {
    case AqeResultCode::OK:
      return FAS_PSTR("OK");
    case AqeResultCode::QueueFull:
      return FAS_PSTR("Queue Full");
    case AqeResultCode::DirPin2msPauseAdded:
      return FAS_PSTR("Dir Pin 2ms Pause Added");
    case AqeResultCode::DirChangePauseInjected:
      return FAS_PSTR("Dir Change Pause Injected");
    case AqeResultCode::DirPinIsBusy:
      return FAS_PSTR("Direction Pin is Busy");
    case AqeResultCode::WaitForEnablePinActive:
      return FAS_PSTR("Waiting for Enable Pin Active");
    case AqeResultCode::DeviceNotReady:
      return FAS_PSTR("Device Not Ready");
    case AqeResultCode::ErrorTicksTooLow:
      return FAS_PSTR("Error: Ticks Too Low");
    case AqeResultCode::ErrorEmptyQueueToStart:
      return FAS_PSTR("Error: Empty Queue to Start");
    case AqeResultCode::ErrorNoDirPinToToggle:
      return FAS_PSTR("Error: No Direction Pin to Toggle");
    case AqeResultCode::ErrorCommandsSuspended:
      return FAS_PSTR("Error: Commands Suspended");
    default:
      return FAS_PSTR("Unknown Error");
  }
}
#define AQE_OK AqeResultCode::OK
#define AQE_QUEUE_FULL AqeResultCode::QueueFull
#define AQE_DIR_PIN_2MS_PAUSE_ADDED AqeResultCode::DirPin2msPauseAdded
#define AQE_DIR_CHANGE_PAUSE_INJECTED AqeResultCode::DirChangePauseInjected
#define AQE_DIR_PIN_IS_BUSY AqeResultCode::DirPinIsBusy
#define AQE_WAIT_FOR_ENABLE_PIN_ACTIVE AqeResultCode::WaitForEnablePinActive
#define AQE_DEVICE_NOT_READY AqeResultCode::DeviceNotReady
#define AQE_ERROR_TICKS_TOO_LOW AqeResultCode::ErrorTicksTooLow
#define AQE_ERROR_EMPTY_QUEUE_TO_START AqeResultCode::ErrorEmptyQueueToStart
#define AQE_ERROR_NO_DIR_PIN_TO_TOGGLE AqeResultCode::ErrorNoDirPinToToggle
#define AQE_ERROR_COMMANDS_SUSPENDED AqeResultCode::ErrorCommandsSuspended

// Define the MoveResultCode enum with equivalent values
enum class MoveResultCode : int8_t {
  OK = 0,
  ErrorNoDirectionPin = -1,    // Equivalent to MOVE_ERR_NO_DIRECTION_PIN
  ErrorSpeedIsUndefined = -2,  // Equivalent to MOVE_ERR_SPEED_IS_UNDEFINED
  ErrorAccelerationIsUndefined =
      -3  // Equivalent to MOVE_ERR_ACCELERATION_IS_UNDEFINED
};

static inline bool moveIsOk(MoveResultCode status) {
  return status == MoveResultCode::OK;
}

static inline const char* toString(MoveResultCode code) {
  switch (code) {
    case MoveResultCode::OK:
      return toString(AqeResultCode::OK);
    case MoveResultCode::ErrorNoDirectionPin:
      return FAS_PSTR("Error: No Direction Pin");
    case MoveResultCode::ErrorSpeedIsUndefined:
      return FAS_PSTR("Error: Speed is Undefined");
    case MoveResultCode::ErrorAccelerationIsUndefined:
      return FAS_PSTR("Error: Acceleration is Undefined");
    default:
      return FAS_PSTR("Unknown Error");
  }
}

// Macros for easier access to enum values
#define MOVE_OK MoveResultCode::OK
#define MOVE_ERR_NO_DIRECTION_PIN MoveResultCode::ErrorNoDirectionPin
#define MOVE_ERR_SPEED_IS_UNDEFINED MoveResultCode::ErrorSpeedIsUndefined
#define MOVE_ERR_ACCELERATION_IS_UNDEFINED \
  MoveResultCode::ErrorAccelerationIsUndefined

// MoveTimedResultCode values 0..6 mirror AqeResultCode so that tmrFrom() is a
// value-preserving cast; MoveBusy/MoveEmpty sit above the AQE range to avoid
// aliasing AqeResultCode::DirChangePauseInjected. Every negative AqeResultCode
// needs its mirror entry here for the same reason: AqeResultCode reserves -4
// for nothing, but ErrorCommandsSuspended is -5 precisely because
// ErrorMoveTooLarge (-4) already sits in this enum, and a -4 AqeResultCode
// would cast to MOVE_TIMED_TOO_LARGE_ERROR.
enum class MoveTimedResultCode : int8_t {
  OK = 0,
  QueueFull = 1,
  DirPinIsBusy = 2,
  WaitForEnablePinActive = 3,
  DeviceNotReady = 4,
  DirPin2msPauseAdded = 5,
  DirChangePauseInjected = 6,
  MoveBusy = 7,
  MoveEmpty = 8,
  ErrorTicksTooLow = -1,
  ErrorEmptyQueueToStart = -2,
  ErrorNoDirPinToToggle = -3,
  ErrorMoveTooLarge = -4,
  ErrorCommandsSuspended = -5,
};

static inline bool moveTimedIsOk(MoveTimedResultCode status) {
  return status == MoveTimedResultCode::OK;
}

static inline MoveTimedResultCode tmrFrom(AqeResultCode res) {
  return static_cast<MoveTimedResultCode>(res);
}

static inline const char* toString(MoveTimedResultCode code) {
  switch (code) {
    case MoveTimedResultCode::OK:
      return toString(AqeResultCode::OK);
    case MoveTimedResultCode::QueueFull:
      return toString(AqeResultCode::QueueFull);
    case MoveTimedResultCode::DirPinIsBusy:
      return toString(AqeResultCode::DirPinIsBusy);
    case MoveTimedResultCode::WaitForEnablePinActive:
      return toString(AqeResultCode::WaitForEnablePinActive);
    case MoveTimedResultCode::DeviceNotReady:
      return toString(AqeResultCode::DeviceNotReady);
    case MoveTimedResultCode::DirPin2msPauseAdded:
      return toString(AqeResultCode::DirPin2msPauseAdded);
    case MoveTimedResultCode::DirChangePauseInjected:
      return toString(AqeResultCode::DirChangePauseInjected);
    case MoveTimedResultCode::MoveBusy:
      return FAS_PSTR("Move still ongoing");
    case MoveTimedResultCode::MoveEmpty:
      return FAS_PSTR("Queue has been empty");
    case MoveTimedResultCode::ErrorTicksTooLow:
      return toString(AqeResultCode::ErrorTicksTooLow);
    case MoveTimedResultCode::ErrorEmptyQueueToStart:
      return toString(AqeResultCode::ErrorEmptyQueueToStart);
    case MoveTimedResultCode::ErrorNoDirPinToToggle:
      return toString(AqeResultCode::ErrorNoDirPinToToggle);
    case MoveTimedResultCode::ErrorMoveTooLarge:
      return FAS_PSTR("Error: Move too large");
    case MoveTimedResultCode::ErrorCommandsSuspended:
      return toString(AqeResultCode::ErrorCommandsSuspended);
    default:
      return FAS_PSTR("Unknown Error");
  }
}
#define MOVE_TIMED_OK MoveTimedResultCode::OK
#define MOVE_TIMED_BUSY MoveTimedResultCode::MoveBusy
#define MOVE_TIMED_EMPTY MoveTimedResultCode::MoveEmpty
#define MOVE_TIMED_TOO_LARGE_ERROR MoveTimedResultCode::ErrorMoveTooLarge
#define MOVE_TIMED_COMMANDS_SUSPENDED MoveTimedResultCode::ErrorCommandsSuspended

enum class DelayResultCode : int8_t { OK = 0, TOO_LOW = -1, TOO_HIGH = -2 };

static inline bool delayIsValid(DelayResultCode status) {
  return status == DelayResultCode::OK;
}

static inline const char* toString(DelayResultCode status) {
  switch (status) {
    case DelayResultCode::OK:
      return toString(AqeResultCode::OK);
    case DelayResultCode::TOO_LOW:
      return FAS_PSTR("Delay Too Low");
    case DelayResultCode::TOO_HIGH:
      return FAS_PSTR("Delay Too High");
    default:
      return FAS_PSTR("Unknown Delay Status");
  }
}

// Macros for simpler usage if needed
#define DELAY_OK DelayResultCode::OK
#define DELAY_TOO_LOW DelayResultCode::TOO_LOW
#define DELAY_TOO_HIGH DelayResultCode::TOO_HIGH

#endif /* FAS_RESULT_CODES_H */
